package com.aluracursos.libros.libros.principal;

import ch.qos.logback.core.encoder.JsonEscapeUtil;
import com.aluracursos.libros.libros.model.Datos;
import com.aluracursos.libros.libros.model.DatosLibros;
import com.aluracursos.libros.libros.service.ConsumoAPI;
import com.aluracursos.libros.libros.service.ConvierteDatos;

import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Principal {

    private static final String URL_BASE = "https://gutendex.com/books/";
    private ConsumoAPI consumoAPI = new ConsumoAPI();
    private ConvierteDatos conversor = new ConvierteDatos();
    private Scanner teclado = new Scanner(System.in);

    public  void muestraElMenu () {

 var json = consumoAPI.obtenerDatos(URL_BASE);
        System.out.println(json);
        var datos = conversor.obtenerDatos(json, Datos.class);
        System.out.println(datos);

        // TOP 10 LIBROS MAS DESCARGADOS

        System.out.println("TOP 10 LIBROS MAS DESCARGADOS");
        datos.resultado().stream()
                .sorted(Comparator.comparing(DatosLibros::numeroDeDescargas).reversed())
                .limit(10)
                .map(l -> l.titulo().toUpperCase())
                .forEach(System.out::println);

        //  BUSQUEDA DEL LIBRO POR NOMBRE
        System.out.println("Ingrese el nombre del libro que desea buscar");
        var tituloLibro = teclado.nextLine();
        json = consumoAPI.obtenerDatos(URL_BASE + "?search=" + tituloLibro.replace(" ", "+"));
        var datosBusqueda = conversor.obtenerDatos(json, Datos.class);
        Optional<DatosLibros> libroBuscado = datosBusqueda.resultado()
                .stream().filter(l -> l.titulo().toUpperCase().contains(tituloLibro.toUpperCase()))
                .findFirst();
        if (libroBuscado.isPresent()) {
            System.out.println("Libro encontrado");
            System.out.println(libroBuscado.get());
        } else {
            System.out.println("Libro no encontrado");
        }

        // TRABAJANDO CON ESTADISTICAS

        DoubleSummaryStatistics est = datos.resultado().stream()
                .filter(d -> d.numeroDeDescargas() > 0)
                .collect(Collectors.summarizingDouble(DatosLibros::numeroDeDescargas));

        System.out.println("CANTIDAD MEDIA DE DESCARGAS: " + est.getAverage());
        System.out.println("CANTIDAD MAXIMA DE DESCARGAS: " + est.getMax());
        System.out.println("CANTIDAD MINIMA DE DESCARGAS: " + est.getMin());
        System.out.println("CANTIDAD DE REGISTROS EVALUADOS: " + est.getCount());

    }

}
